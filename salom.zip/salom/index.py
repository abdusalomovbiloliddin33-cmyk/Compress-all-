#!/usr/bin/env python3
"""
Smart Compressor - GUI (Tkinter)
Features:
 - Lossless chunk-based compression using zstandard
 - GUI with progress bar and logs
 - Worker threads so GUI does not hang
 - Cancel button
 - Compression level selector
 - Robust error handling and checksum verification
"""
import tkinter as tk
from tkinter import ttk, filedialog, messagebox
import os, struct, hashlib, threading, time, queue
import zstandard as zstd

MAGIC = b'SCMPv1'
CHUNK_SIZE = 8 * 1024 * 1024  # 8 MB by default

def sha256_bytes(b: bytes) -> bytes:
    return hashlib.sha256(b).digest()

# Streamed compress with progress callback
def compress_stream(input_path, output_path, level, progress_cb, cancel_event):
    cctx = zstd.ZstdCompressor(level=level)
    total = os.path.getsize(input_path)
    processed = 0
    try:
        with open(input_path, 'rb') as fin, open(output_path, 'wb') as fout:
            fout.write(MAGIC)
            fout.write(struct.pack('<Q', total))
            while True:
                if cancel_event.is_set():
                    raise RuntimeError("Compression cancelled by user")
                chunk = fin.read(CHUNK_SIZE)
                if not chunk:
                    break
                compressed = cctx.compress(chunk)
                if len(compressed) >= len(chunk):
                    block_flag = 0
                    data_to_write = chunk
                else:
                    block_flag = 1
                    data_to_write = compressed
                fout.write(struct.pack('<B', block_flag))
                fout.write(struct.pack('<I', len(chunk)))
                fout.write(struct.pack('<I', len(data_to_write)))
                checksum = sha256_bytes(chunk)
                fout.write(checksum)
                fout.write(data_to_write)
                processed += len(chunk)
                progress_cb(processed, total, "compressing")
        return {"ok": True, "total": total}
    except Exception as e:
        # if incomplete output file exists, try to remove it
        try:
            if os.path.exists(output_path):
                os.remove(output_path)
        except Exception:
            pass
        return {"ok": False, "error": str(e)}

def decompress_stream(input_path, output_path, progress_cb, cancel_event):
    dctx = zstd.ZstdDecompressor()
    try:
        with open(input_path, 'rb') as fin:
            magic = fin.read(len(MAGIC))
            if magic != MAGIC:
                raise RuntimeError("Fayl SCMP format emas yoki noto‘g‘ri versiya.")
            orig_size = struct.unpack('<Q', fin.read(8))[0]
            processed = 0
            with open(output_path, 'wb') as fout:
                while True:
                    if cancel_event.is_set():
                        raise RuntimeError("Decompression cancelled by user")
                    header = fin.read(1)
                    if not header:
                        break
                    block_flag = struct.unpack('<B', header)[0]
                    orig_len = struct.unpack('<I', fin.read(4))[0]
                    comp_len = struct.unpack('<I', fin.read(4))[0]
                    checksum = fin.read(32)
                    data = fin.read(comp_len)
                    if block_flag == 0:
                        chunk = data
                    else:
                        chunk = dctx.decompress(data, max_output_size=orig_len)
                    if sha256_bytes(chunk) != checksum:
                        raise RuntimeError("Checksum mismatch — fayl buzilgan.")
                    fout.write(chunk)
                    processed += len(chunk)
                    progress_cb(processed, orig_size, "decompressing")
        return {"ok": True, "total": orig_size}
    except Exception as e:
        try:
            if os.path.exists(output_path):
                os.remove(output_path)
        except Exception:
            pass
        return {"ok": False, "error": str(e)}

# ---------- GUI ----------
class App:
    def __init__(self, root):
        self.root = root
        root.title("Smart Compressor - GUI")
        root.geometry("560x360")
        root.resizable(False, False)

        self.log_q = queue.Queue()
        self.cancel_event = threading.Event()
        self.worker = None

        # Top frame - actions
        top = ttk.Frame(root, padding=10)
        top.pack(fill='x')

        ttk.Label(top, text="Smart Compressor", font=("Segoe UI", 14)).pack(anchor='w')

        self.level_var = tk.IntVar(value=19)
        level_frame = ttk.Frame(top)
        level_frame.pack(anchor='w', pady=(8,4))
        ttk.Label(level_frame, text="Compression level (1-22):").pack(side='left')
        self.level_spin = ttk.Spinbox(level_frame, from_=1, to=22, width=5, textvariable=self.level_var)
        self.level_spin.pack(side='left', padx=6)

        btn_frame = ttk.Frame(top)
        btn_frame.pack(fill='x', pady=6)

        self.compress_btn = ttk.Button(btn_frame, text="Faylni siqish", command=self.on_compress)
        self.compress_btn.pack(side='left', padx=4)

        self.decompress_btn = ttk.Button(btn_frame, text="Faylni asl holatiga keltirish", command=self.on_decompress)
        self.decompress_btn.pack(side='left', padx=4)

        self.cancel_btn = ttk.Button(btn_frame, text="Bekor qilish", command=self.on_cancel, state='disabled')
        self.cancel_btn.pack(side='left', padx=12)

        # Progress
        progress_frame = ttk.Frame(root, padding=10)
        progress_frame.pack(fill='x')
        self.progress = ttk.Progressbar(progress_frame, orient='horizontal', length=520, mode='determinate')
        self.progress.pack()
        self.status_lbl = ttk.Label(progress_frame, text="Holat: tayyor")
        self.status_lbl.pack(anchor='w', pady=(6,0))

        # Log box
        log_frame = ttk.LabelFrame(root, text="Log", padding=6)
        log_frame.pack(fill='both', expand=True, padx=10, pady=8)
        self.log_text = tk.Text(log_frame, height=8, state='disabled', wrap='word')
        self.log_text.pack(fill='both', expand=True)

        # Poll queue for logs/progress
        root.after(200, self._poll_queue)

    def _log(self, *parts):
        s = " ".join(str(p) for p in parts)
        self.log_q.put(("log", s))

    def _set_progress(self, value, maximum):
        self.log_q.put(("progress", (value, maximum)))

    def _set_status(self, s):
        self.log_q.put(("status", s))

    def _poll_queue(self):
        try:
            while True:
                item = self.log_q.get_nowait()
                typ, val = item
                if typ == "log":
                    self.log_text.config(state='normal')
                    self.log_text.insert('end', val + "\n")
                    self.log_text.see('end')
                    self.log_text.config(state='disabled')
                elif typ == "progress":
                    v, m = val
                    try:
                        pct = int(v * 100 / m) if m > 0 else 0
                    except Exception:
                        pct = 0
                    self.progress['maximum'] = m
                    self.progress['value'] = v
                    self.status_lbl.config(text=f"Holat: {pct}% ({v}/{m} bayt)")
                elif typ == "status":
                    self.status_lbl.config(text="Holat: " + val)
        except queue.Empty:
            pass
        self.root.after(200, self._poll_queue)

    def on_cancel(self):
        if self.worker and self.worker.is_alive():
            self.cancel_event.set()
            self._log("Bekor qilish so‘rovi yuborildi...")
            self.cancel_btn.config(state='disabled')

    def _start_worker(self, target, args):
        if self.worker and self.worker.is_alive():
            messagebox.showwarning("Ogohlantirish", "Boshqa jarayon ishlamoqda. Iltimos tugashini kuting yoki bekor qiling.")
            return False
        self.cancel_event.clear()
        self.worker = threading.Thread(target=target, args=args, daemon=True)
        self.worker.start()
        self.cancel_btn.config(state='normal')
        return True

    # Progress callback for worker functions
    def progress_cb(self, processed, total, mode):
        self._set_progress(processed, total)
        # also log occasionally
        if processed % (CHUNK_SIZE * 4) == 0 or processed == total:
            self._log(f"{mode}: {processed}/{total} bayt")

    def on_compress(self):
        inp = filedialog.askopenfilename(title="Siqiladigan faylni tanlang")
        if not inp:
            return
        default_out = os.path.splitext(os.path.basename(inp))[0] + ".scmp"
        out = filedialog.asksaveasfilename(initialfile=default_out, defaultextension=".scmp",
                                           filetypes=[("SCMP fayllar", "*.scmp")],
                                           title="Siqilgan faylni saqlash joyini tanlang")
        if not out:
            return
        level = int(self.level_var.get())
        self._log("Compression started:", inp, "->", out, f"level={level}")
        self._set_status("Siqilmoqda...")
        def worker():
            res = compress_stream(inp, out, level, lambda p,t,m: self.progress_cb(p,t,m), self.cancel_event)
            if res.get("ok"):
                ratio = (res["total"] / os.path.getsize(out)) if os.path.exists(out) and os.path.getsize(out)>0 else 0
                self._log("Compression finished. Original:", res["total"], "bytes; Compressed:", os.path.getsize(out), "bytes; Ratio ~", f"{ratio:.2f}x")
                self._set_status("Siqish yakunlandi")
                messagebox.showinfo("Tayyor", f"Siqish tugadi:\n{out}")
            else:
                self._log("Xato:", res.get("error"))
                self._set_status("Xato yuz berdi")
                messagebox.showerror("Xato", str(res.get("error")))
            self.cancel_event.clear()
            self.cancel_btn.config(state='disabled')
        self._start_worker(worker, ())

    def on_decompress(self):
        inp = filedialog.askopenfilename(title="Siqilgan (.scmp) faylni tanlang", filetypes=[("SCMP fayllar", "*.scmp")])
        if not inp:
            return
        default_out = os.path.splitext(os.path.basename(inp))[0] + ".restored"
        out = filedialog.asksaveasfilename(initialfile=default_out, title="Asl faylni qayerga saqlashni tanlang")
        if not out:
            return
        self._log("Decompression started:", inp, "->", out)
        self._set_status("Tiklanmoqda...")
        def worker():
            res = decompress_stream(inp, out, lambda p,t,m: self.progress_cb(p,t,m), self.cancel_event)
            if res.get("ok"):
                self._log("Decompression finished. Restored bytes:", res["total"])
                self._set_status("Tiklash yakunlandi")
                messagebox.showinfo("Tayyor", f"Fayl tiklandi:\n{out}")
            else:
                self._log("Xato:", res.get("error"))
                self._set_status("Xato yuz berdi")
                messagebox.showerror("Xato", str(res.get("error")))
            self.cancel_event.clear()
            self.cancel_btn.config(state='disabled')
        self._start_worker(worker, ())

def main():
    root = tk.Tk()
    app = App(root)
    root.mainloop()

if __name__ == "__main__":
    main()
